#!/usr/bin/env python3
"""
P4DC CTF — The Unwritten Algorithm
Offline Probe & Verification Utility

Use this utility to inspect public samples and verify your candidate output
for the challenge sequence.
"""

import sys
import json
import base64
import hashlib
import hmac
import struct

CHALLENGE_INPUT = "P4DC{c0gn1t1v3_tr4nsf0rm_v2_2026}"
CIPHERTEXT_B64 = "zKzNzAY5HfdL6lD24cvufZLRj0TFFis2+F/R+FY="
TAG_B64 = "uCxRyaqmUM2RCOq0xkCvrw=="

def verify_output(candidate: str):
    candidate = candidate.strip()
    if not candidate:
        print("[-] Error: Candidate output cannot be empty.")
        return False

    key = hashlib.sha256(candidate.encode('utf-8')).digest()
    ciphertext = base64.b64decode(CIPHERTEXT_B64)
    expected_tag = base64.b64decode(TAG_B64)

    calculated_tag = hmac.new(key, ciphertext, hashlib.sha256).digest()[:16]

    if not hmac.compare_digest(calculated_tag, expected_tag):
        print("[-] Verification failed: Candidate output does NOT match the algorithm's expected output.")
        print("[-] Double-check your inferred shift rules, character permutations, vowel handling, and parity fold.")
        return False

    # Keystream decryption
    keystream = bytearray()
    counter = 0
    while len(keystream) < len(ciphertext):
        block = hashlib.sha256(key + struct.pack(">I", counter)).digest()
        keystream.extend(block)
        counter += 1

    decrypted_flag = bytes(a ^ b for a, b in zip(ciphertext, keystream[:len(ciphertext)])).decode('utf-8')
    print("[+] ========================================================")
    print("[+] SUCCESS! Transformation output verified!")
    print(f"[+] Recovered Flag: {decrypted_flag}")
    print("[+] ========================================================")
    return True

def show_samples():
    try:
        with open("samples.json", "r") as f:
            data = json.load(f)
        print(f"Loaded {len(data)} sample pairs from samples.json:\n")
        for s in data[:10]:
            print(f"  Input : {repr(s['input']):<20} -> Output: {repr(s['output'])}")
        if len(data) > 10:
            print(f"  ... and {len(data) - 10} more in samples.json")
    except Exception as e:
        print(f"[-] Could not read samples.json: {e}")

def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python3 algorithm_probe.py --samples")
        print("  python3 algorithm_probe.py --challenge")
        print("  python3 algorithm_probe.py --verify \"<your_computed_output>\"")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "--samples":
        show_samples()
    elif cmd == "--challenge":
        print("==================================================")
        print("CHALLENGE SEQUENCE:")
        print(f"  Input: {CHALLENGE_INPUT}")
        print("Compute the transformed output for this input, then run:")
        print("  python3 algorithm_probe.py --verify \"<your_output>\"")
        print("==================================================")
    elif cmd == "--verify":
        if len(sys.argv) < 3:
            print("[-] Error: Missing candidate output argument.")
            sys.exit(1)
        candidate = sys.argv[2]
        verify_output(candidate)
    else:
        print(f"[-] Unknown command: {cmd}")
        sys.exit(1)

if __name__ == "__main__":
    main()
