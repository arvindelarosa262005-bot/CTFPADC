#!/usr/bin/env python3
"""
P4DC CTF — The Unwritten Algorithm
Solution Starter Template

Implement the inferred transformation algorithm in `transform(s)`.
"""

import json

def transform(s: str) -> str:
    """
    Reverse-engineered transformation algorithm.
    TODO: Fill in your implementation based on the rules inferred from samples.json.
    """
    # [YOUR IMPLEMENTATION HERE]
    return s

def test_samples():
    with open("samples.json", "r") as f:
        samples = json.load(f)

    passed = 0
    failed = 0
    for idx, item in enumerate(samples):
        inp = item["input"]
        expected = item["output"]
        actual = transform(inp)
        if actual == expected:
            passed += 1
        else:
            failed += 1
            if failed <= 3:
                print(f"[FAIL] Sample #{idx+1} {repr(inp)}: expected {repr(expected)}, got {repr(actual)}")

    print(f"\nResult: {passed}/{len(samples)} samples passed.")
    if failed == 0:
        challenge_input = "P4DC{c0gn1t1v3_tr4nsf0rm_v2_2026}"
        ans = transform(challenge_input)
        print("\n[+] All samples passed!")
        print(f"[+] Computed Challenge Output: {ans}")
        print(f"[+] Run: python3 algorithm_probe.py --verify {repr(ans)}")

if __name__ == "__main__":
    test_samples()
